lista = [58,77,225,226,95,94,181,83]
lista.sort()
print(lista)